import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import datetime
import time
import net

import json
import talks


PLUGIN='plugin.video.cubetv'
ADDON = xbmcaddon.Addon(id=PLUGIN)

image='http://streamtvbox.club/apk/'

auth=ADDON.getSetting('authtoken')


URL_SITE= 'https://mediacube.co'
BASEURL = URL_SITE+'/content/p/id/1/'

ERRORLOGO = xbmc.translatePath('special://home/addons/plugin.video.cubetv/resources/art/redx.png')

THESITE='mediacube.co'

if ADDON.getSetting('hls')=='true':
   UA='iPhone'
else:    
    UA='XBMC'


net=net.Net()


                

def OPEN_URL(url):
    req = urllib2.Request(url, headers={'User-Agent' : "Magic Browser"}) 
    con = urllib2.urlopen( req )
    link= con.read()
    return link



datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
cookie_path = os.path.join(datapath, 'cookies')
cookie_jar = os.path.join(cookie_path, THESITE+'.lwp')
channeljs=os.path.join(cookie_path, "channel.js")
cookies_123 = os.path.join(cookie_path, '123.lwp')


if os.path.exists(cookie_path) == False:
        os.makedirs(cookie_path)
    
                         
                      
def EXIT():
        xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
        xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
    
    
if ADDON.getSetting('user')=='' or ADDON.getSetting('pass')=='' :
    dialog = xbmcgui.Dialog()
    if dialog.yesno(THESITE.upper(), "If You Dont Have An Account", "Please Sign Up At",THESITE.upper(),"Exit","Carry On"):
        
        dialog.ok(THESITE.upper(), "You Now Need To Input", "Your [COLOR yellow]Username[/COLOR]")
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, THESITE.upper())
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText() 
        ADDON.setSetting('user',search_entered)
        
        dialog.ok(THESITE.upper(), "You Now Need To Input", "Your [COLOR yellow]Password[/COLOR]")
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, THESITE.upper())
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText() 
        ADDON.setSetting('pass',search_entered)
        ADDON.setSetting('login_time','2000-01-01 00:00:00')
    else:
        EXIT()

        
def KICKOUT():
        dialog = xbmcgui.Dialog()
        dialog.ok("Please Check Your Details & Try Again", "Username : "+ADDON.getSetting('user'), "Password : "+ ADDON.getSetting('pass'), "[COLOR red]is Wrong Please Sign up @ "+THESITE.upper()+"[/COLOR]")
        ADDON.setSetting('user','')
        ADDON.setSetting('pass','')
        os.remove(SETTINGS)
        try:
            os.remove(cookie_jar)
        except:
            pass
        EXIT()

def LOGOUT():
    net.set_cookies(cookie_jar)
    html = net.http_GET(site).content
    match=re.compile(' href="(.+?)">Log Out</a>').findall(html)[0]
    net.set_cookies(cookie_jar)
    logout = net.http_GET(match.replace('#038;','')).content
    if 'You are now logged out' in logout:
        print '===============LOGGED OUT !!==============='
        dialog = xbmcgui.Dialog()
        dialog.ok(THESITE.upper(),'', "You Are Now Logged Out", "")
        EXIT()
        
    
    


def Login():
    print '###############    LOGIN TO CUBE   #####################'

    loginurl = 'https://'+THESITE+'/wp-login.php'
    username = ADDON.getSetting('user')
    password = ADDON.getSetting('pass')

    data     = {'pwd': password,
                                            'log': username,
                                            'wp-submit': 'Log In','redirect_to':'https://'+THESITE+'/wp-admin','testcookie':'1','rememberme':'forever'}




    headers  = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Encoding':'gzip, deflate, br',
                'Accept-Language':'en-US,en;q=0.8',
                'Cache-Control':'no-cache',
                'Connection':'keep-alive',
                'Content-Type':'application/x-www-form-urlencoded',
                'Host':'mediacube.co',
                'Origin':'https://'+THESITE,
                'Pragma':'no-cache',
                'Referer':'https://'+THESITE+'/wp-login.php',
                'Upgrade-Insecure-Requests':'1',
                'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36'}


    html = net.http_POST(loginurl, data, headers).content
    if 'Lost your password</a>' in html:
        KICKOUT()
        return False
    else:
        if os.path.exists(cookie_path) == False:
                os.makedirs(cookie_path)
        net.save_cookies(cookie_jar)

        net.set_cookies(cookie_jar)
        return True



def parse_date(dateString):
    import time
    return datetime.datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))


def sessionExpired():
    try:
        a=open(cookie_jar).read()
        expiry=re.compile('expires="(.+?)"').findall(a)[0]
        expiry=expiry [0:len(expiry)-1]
    except:
        expiry='2000-01-01 00:00:00'


    now        = datetime.datetime.today()
 
    
    prev = parse_date(expiry)


    return (now > prev)


def server():
    net.set_cookies(cookie_jar)
    a=net.http_GET(URL_SITE+'/api/matrix/channels',headers={'User-Agent' :UA}).content
    return a



CUBEINI = os.path.join(ADDON.getAddonInfo('path'), 'addons.ini')
def CreatIniNow(name,url,mode,iconimage,play,date,description,cat_id):

        play='False'
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&play="+urllib.quote_plus(play)+"&date="+urllib.quote_plus(date)+"&description="+urllib.quote_plus(description)+"&page=&cat_id="+str(cat_id)
        a=name.replace('[COLOR green]','').replace('[/COLOR]','')+'='+u
        f = open(CUBEINI, mode='a')
        f.write(a+'\n')
        f.close()
        
    
def CATEGORIES():
    if Login():  
        try:
           net.set_cookies(cookie_jar)

           link = json.loads(server())
           if ADDON.getSetting('genre')=='true':
               uniques=[]
               uniquesurl=[]
               data=link['categories']
               ret = ''
               for j in data:
                   url = j
                   name = data[j].encode("utf-8")       
                   if name not in uniques:
                       uniques.append(name)
                       uniquesurl.append(url)
                       addDir(name,url,4,'http://sgstreams.ca/images/cat_images/'+name.lower().replace(' ','')+'.png','','','')


               
           else:
               data=link['channels']
               for field in data:
                   id= str(field['id'])
                   name= field['title'].encode("utf-8")            
                   iconimage=field['image']
                   cat_id=field['cat_id']

               
           #addDir('[COLOR gold].Upcoming Matches[/COLOR]','url',1999,'http://sgstreams.ca/images/cat_images/matches.png','','','')
           addDir('[COLOR blanchedalmond].Tools & Settings[/COLOR]','url',16000,'http://sgstreams.ca/images/cat_images/tools.png','','','')
           addDir('[COLOR red].View Calendar[/COLOR]','http://sportsmania.eu/sites/ukcalendar.html',2009,'http://sgstreams.ca/images/cat_images/ukcalendar.png','','','')
           addDir('[COLOR red].View USA Calendar[/COLOR]','http://sportsmania.eu/sites/usacalendar.html',2009,'http://sgstreams.ca/images/cat_images/usacalendar.png','','','')        
           addDir('[COLOR pink].Sports On Demand[/COLOR]',URL_SITE+'/channels1.php',2005,'http://sgstreams.ca/images/cat_images/sportsondemand.png','','','')
           addDir('[COLOR plum]-->>.MatchDay Pass <<---[/COLOR]',URL_SITE+'/apisprotected/plp.php',2005,'http://sgstreams.ca/images/cat_images/plp.png','','','')
           addDir('[COLOR mediumorchid]-->>.American Game Pass <<--[/COLOR]',URL_SITE+'/usa.php',20050,'http://sgstreams.ca/images/cat_images/usa.png','','','')
           addDir('[COLOR lime]OnDemand[/COLOR]','url',12000,'http://sgstreams.ca/images/cat_images/search.png','','','')

           xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE) 
           data=link['channels']
           for field in data:
               id= str(field['id'])
               name= field['title'].encode("utf-8")
               iconimage=field['image']
               cat_id=field['cat_id']
               CreatIniNow(name,id,2,iconimage,'False','','',cat_id)

               
        except:    
            addDir('Delete Cookie','.f4m',203,'','','','',0)
            addDir('Change Username or Password','.f4m',16002,'','','','',0)

            
def Show_Dialog():
    dialog = xbmcgui.Dialog()
    dialog.ok("", '',"All Done Try Now", "")
        
def REPLAY():
        ok=True
        cmd = 'plugin://plugin.video.footballreplays/'
        xbmc.executebuiltin('XBMC.Container.Update(%s)' % cmd)
        return ok
 
def GENRES(name,url):

    link = json.loads(server())
    data=link['channels']
    for field in data:
        id= field['id']
        title= field['title'].encode("utf-8")
        genre= field['cat_id']
        iconimage=image+id+'.png'
        if url == genre:
            addDir(title,id,2,iconimage,'False','','')
    if url=='53':
        try:SportsOnDemand(URL_SITE+'/plp.php',SORT=True)
        except:pass
    if url=='47':
        try:SportsOnDemand(URL_SITE+'mlb.php',SORT=True)
        except:pass
    if url=='36':
        try:SportsOnDemand(URL_SITE+'usa.php',SORT=True)
        except:pass
    if url=='43':
        try:SportsOnDemand(URL_SITE+'nhl.php',SORT=True)
        except:pass 
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)           
        
    
def istream():
       
        xbmc.executebuiltin('ActivateWindow(videos,plugin://script.icechannel)')

 
     
    
def OPEN_MAGIC(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent' , "Magic Browser")
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

    
def getme():
   return '|User-Agent=Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'

def getday():
    today = datetime.datetime.today()
    return today.strftime("%A")
   
def schedule(url):
    if 'usa' in url:
       media=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons','usa')
    else:
       media=os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icons','uk')
       
    net.set_cookies(cookie_jar)
    response = net.http_GET(url)
    link = response.content.replace('\t','').replace('\n','').replace('\r','')
    titles=re.compile('<div class="panel-heading"><center><b>(.+?)</b></center>').findall(link)
    for heading in titles:
        if not 'sport' in heading.lower():
           if getday().lower() in heading.lower():           
              addDir('[COLOR cyan]*** %s ***[/COLOR]'% heading,'url',200,'','','','')

              links=link.split(heading)[1]
              links=links.split('</table>')[0]
              links=links.split('<tr>')
              for p in links:
                  try:
                      match=re.compile('<th bgcolor="(.+?)"><font color=".+?">(.+?)</font>',re.DOTALL).findall(p)

                      font= match[0][0]
                      if font =='#624F27':       #CRICKET/NFL
                        font = 'sienna'
                      if font =='#0000FF':       #FOOTBALL/SOCCER
                        font = 'royalblue'
                      if font =='#006F09':       #RUGBY/NBA
                        font = 'mediumseagreen'
                      if font =='#69005F':       #SNOOKER/NHL
                        font = 'purple'
                      if font =='#FF0000':       #MOTOR/MLB
                        font = 'red'
                      if font =='#E68300':       #MMA
                        font = 'orange'
                      if font =='#000000':       #HORSE
                        font = 'grey'
                      if font =='#ADFF2F':       #TENNIS
                        font = 'lime'
                      if font =='#FF1493':       #GOLF
                        font = 'pink'
                      if font =='#40E0D0':       #GAA/NASCAR
                        font = 'turquoise'
                      if font =='#DAA520':       #DARTS/NCAA
                        font = 'darkcyan'
                          
                          
                          
                      time= match[0][1]
                      name= match[1][1]
                      channels= match[2][1].replace('Game Zone / ','').replace('Game Zone','Events').strip()
        
                      NAME= '[COLOR %s]%s - %s -[/COLOR][COLOR green]%s[/COLOR]' % (font,time.replace('-',''),name.replace('-',''),channels.replace('-',''))
                      
                      addDir(NAME.encode('utf-8'),'url',2,media+'/'+font+'.png','GET_EVENT','','')
                  except:pass
        
    xbmc.executebuiltin('Container.SetViewMode(51)')  

def SportsOnDemand(url,SORT=False):

       ADDME=[]
       net.set_cookies(cookie_jar)
       a=net.http_GET(url,headers={'User-Agent':'XBMC'}).content

       import json
       link=json.loads(a)
       data=link['vod_channels']
       for field in data:
           id= str(field['channel_url'])
           name= field['channel_title'].encode("utf-8")
           if '(' in name:
              date='('+name.split('(')[1]
              name=name.split('(')[0]
              NAME='[COLOR white]%s[/COLOR] - [COLOR yellow]%s[/COLOR]' % (name,date)
           else:
              if not SORT:
                  NAME='[COLOR white]%s[/COLOR]' % (name)
              else:
                 NAME=name.replace('HD','[COLOR green]HD[/COLOR]')
           addDir(NAME,id,2004,'','','','')
       if SORT == True:      
           xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE) 
        

def PlayMikey(name,url,iconimage):
    
    if '.f4m' in url:
        import F4MProxy
        player=F4MProxy.f4mProxyHelper()
        player.playF4mLink(url, name,iconimage)
    else:    
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    
        
        
def PLAY_FROM_EVENTS(name, url, iconimage, play, description):
    name=name.split('[COLOR green]')[1].replace('[/COLOR]','')
    name=name.replace('/',',').strip()
    
    if not 'EPL' in name:
       name.replace('-','').strip()
    nameFINAL=[]
    urlFINAL=[]
    if ',' in name:
       
        nameSelect=[]
        urlSelect=[]
        name=name.split(',')
        for p in name:
            urlSelect.append(p.strip().lower())
            nameSelect.append(p.strip())
        TITLE = urlSelect[xbmcgui.Dialog().select('Please Select Channel', nameSelect)]      
        TITLE=TITLE.replace(' ','').lower().strip()
        if 'matchday' in TITLE:
             try:
                net.set_cookies(cookie_jar)
                a=net.http_GET(URL_SITE+'/protected/plp.php',headers={'User-Agent':'XBMC'}).content
                link=json.loads(a)
                data=link['vod_channels']
                for field in data:
                    id= str(field['channel_url'])
                    YOYO= field['channel_title'].encode("utf-8")
                    if TITLE in YOYO.replace(' ','').lower():
                        urlFINAL.append(id)
                        nameFINAL.append('[COLOR lime]%s[/COLOR]'%(YOYO))
             except:pass   
             link = json.loads(server())
             data=link['channels']
             for field in data:
                 id= str(field['id'])
                 YOYO= field['title'].encode("utf-8")     
                 if TITLE in YOYO.replace(' ','').lower():
                     urlFINAL.append(id)
                     nameFINAL.append('[COLOR lime]%s[/COLOR]'%(YOYO))     
             if urlFINAL:
                 return urlFINAL[xbmcgui.Dialog().select('Multiple Channels Found', nameFINAL)]  
        else:       
           link = json.loads(server())
           data=link['channels']
           for field in data:
               id= str(field['id'])
               YOYO= field['title'].encode("utf-8")     
               if TITLE in YOYO.replace(' ','').lower():
                   urlFINAL.append(id)
                   nameFINAL.append('[COLOR lime]%s[/COLOR]'%(YOYO))
           if urlFINAL:
               return urlFINAL[xbmcgui.Dialog().select('Multiple Channels Found', nameFINAL)] 

    else:
    
        NAME=name.replace(' ','').lower().strip()

        if 'matchday' in NAME:
             try:
                net.set_cookies(cookie_jar)
                a=net.http_GET(URL_SITE+'/apisprotected/plp.php',headers={'User-Agent':'XBMC'}).content
                link=json.loads(a)
                data=link['vod_channels']
                for field in data:
                    id= str(field['channel_url'])
                    YOYO= field['channel_title'].encode("utf-8")
                    if NAME in YOYO.replace(' ','').lower():
                        urlFINAL.append(id)
                        nameFINAL.append('[COLOR lime]%s[/COLOR]'%(YOYO))
             except:pass         
             link = json.loads(server())
             data=link['channels']
             for field in data:
                 id= str(field['id'])
                 NAME_= field['title'].encode("utf-8")   
                 if NAME in NAME_.replace(' ','').lower().strip():
                     urlFINAL.append(id)
                     nameFINAL.append('[COLOR lime]%s[/COLOR]'%(NAME_))
             if urlFINAL:
                 return urlFINAL[xbmcgui.Dialog().select('Multiple Channels Found', nameFINAL)]
        else:       
           link = json.loads(server())
           data=link['channels']
           for field in data:
               id= str(field['id'])
               NAME_= field['title'].encode("utf-8")   
               if NAME in NAME_.replace(' ','').lower().strip():
                   urlFINAL.append(id)
                   nameFINAL.append('[COLOR lime]%s[/COLOR]'%(NAME_))
           if urlFINAL:
               return urlFINAL[xbmcgui.Dialog().select('Multiple Channels Found', nameFINAL)] 
           else:
               return False
         
    
def PLAY_STREAM(name, url, iconimage, play, description):

    
    if play =='GET_EVENT':
        url=PLAY_FROM_EVENTS(name, url, iconimage, play, description)

           
        if not url:
            return Show_Cover()
         
    if len(url)>7:
       stream_url = url

    else:   
       net.set_cookies(cookie_jar)
       stream_url= net.http_GET(URL_SITE+'/api/matrix/channel/%s'%url,headers={'User-Agent' :UA}).content
       if stream_url=='':
           Login()
           net.set_cookies(cookie_jar)
           stream_url= net.http_GET(URL_SITE+'/api/matrix/channel/%s'%url,headers={'User-Agent' :UA}).content
           if stream_url=='':
               return Show_Down()
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title':description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 

def OnDemandLinks(url):
    link = OPEN_URL(url).replace('\n','').replace('\t','').replace('\r','')
    if '<message>' in link:
       message=re.compile('<message>(.+?)</message>').findall (link)
       for name in message:
           addLink(name,'url','','')   

    DIRS=re.compile('<name>(.+?)</name><link>(.+?)</link><thumbnail>(.+?)</thumbnail>',re.DOTALL).findall (link)

    for name , url , iconimage  in DIRS:      
        addDir(name,url,6,iconimage,'','','','')  

    LINKS=re.compile('<title>(.+?)</title.+?<link>(.+?)</link.+?<thumbnail>(.+?)</thumbnail>',re.DOTALL).findall (link)
    
   
    for name , url , iconimage in LINKS:
        addDir(name,url,7,iconimage,'','','','')



def afdah(url):
    url= 'https://m.afdah.org/watch?v='+url

    loginurl = 'https://m.afdah.org/video_info/html5'

    v=url.split('v=')[1]
    data={'v': v}
    headers = {'host': 'm.afdah.org','origin':'https://m.afdah.org', 'referer': url,
               'user-agent':'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_2 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8H7 Safari/6533.18.5','x-requested-with':'XMLHttpRequest'}

    first= net.http_POST(loginurl,data,headers).content

    link= json.loads(first)
    name=[]
    url=[]
    for j in link:
        name.append(j.upper())
   
        url.append(urllib.unquote(link[j][3]))

    THEURL= url[xbmcgui.Dialog().select('Please Select Resolution', name)]
    import requests
    r=requests.get(THEURL,allow_redirects=False, verify=False )   

    r = requests.get(str(r.headers['Location']),allow_redirects=False, verify=False )

    return r.headers['location']

def SEARCH(search_entered):
    headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36'}
    favs = ADDON.getSetting('favs').split(',')
    if 'url' in search_entered:
        keyboard = xbmc.Keyboard('', 'Search Movies / Tv Shows')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()

    search_entered = search_entered.replace(',', '')

    if len(search_entered) == 0:
        return

    if not search_entered in favs:
        favs.append(search_entered)
        ADDON.setSetting('favs', ','.join(favs))

    search_entered = search_entered.replace(' ','%20')
        
    url='http://123movies.to/movie/search/' + str(search_entered).replace(' ','+')
    #print url
    try:
       net.set_cookies(cookies_123)
       LINK=net.http_GET(url,headers=headers).content
       net.save_cookies(cookies_123)
       print 'CLOUDFLARE BYPASSED'
    except:
       import cloudflare
       user='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36'                   
       LINK=cloudflare.solve(url,cookies_123,user)
                          
    #match=re.compile('class="ml-item">.+?a href="(.+?)".+?class="ml-mask jt".+?title="(.+?)">.+?data-original="(.+?)"',re.DOTALL).findall(LINK)
    LINK = LINK.split('"ml-item">')
    for p in LINK:
        try:
           URL=re.compile('a href="(.+?)"',re.DOTALL).findall(p)[0]
           name=re.compile('title="(.+?)"',re.DOTALL).findall(p)[0]
           iconimage=re.compile('img data-original="(.+?)"',re.DOTALL).findall(p)[0]           

           addDir(name,URL,3001,iconimage,'','','','')
        except:pass 
        
def MySearch():
    addDir('[COLOR white]Click to >> [/COLOR][COLOR lime]Search Tv/Movies [COLOR white]<<[/COLOR]','url',3000,'','','','','')
    favs = ADDON.getSetting('favs').split(',')
    for title in favs:
        if len(title)>1:
            addDir(title.title(),title,3000,'','','','','')      
        #addDir(title,NEW_URL,8,'','')


def OnDemandFirstCat():
    addDir('[COLOR white]Search Tv/Movies[/COLOR]','url',3003,'','','','','')
    addDir('[COLOR white]Movies[/COLOR]','movie',4001,'','','','','')
    addDir('[COLOR white]Tv Shows[/COLOR]','series',4001,'','','','','')


def OnDemandSecondCat(url):
    addDir('[COLOR white]Most Popular[/COLOR]','http://123movies.to/movie/filter/%s/view/all/all/all/all/all/'%url,4002,'','','','',0)   
    addDir('[COLOR white]Latest[/COLOR]','http://123movies.to/movie/filter/%s/latest/all/all/all/all/all/'%url,4002,'','','','',0)
    addDir('[COLOR white]Most Favourite[/COLOR]','http://123movies.to/movie/filter/%s/favorite/all/all/all/all/all/'%url,4002,'','','','',0)
    addDir('[COLOR white]Most Rating[/COLOR]','http://123movies.to/movie/filter/%s/rating/all/all/all/all/all/'%url,4002,'','','','',0)
    addDir('[COLOR white]Top IMDb[/COLOR]','http://123movies.to/movie/filter/%s/imdb_mark/all/all/all/all/all/'%url,4002,'','','','',0)
            

def OnDemandThirdCat(url,page):

    page =page+1
    THE_URL =url
    user='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36'
    headers={'User-Agent':user}
                          
    try:
       net.set_cookies(cookies_123)
       LINK=net.http_GET(url+str(page),headers=headers).content
       net.save_cookies(cookies_123)
       print 'CLOUDFLARE BYPASSED'
    except:
       import cloudflare
               
       LINK=cloudflare.solve(url+str(page),cookies_123,user)

    LINK = LINK.split('"ml-item">')
    for p in LINK:
        try:
           URL=re.compile('a href="(.+?)"',re.DOTALL).findall(p)[0]
           name=re.compile('title="(.+?)"',re.DOTALL).findall(p)[0]
           iconimage=re.compile('img data-original="(.+?)"',re.DOTALL).findall(p)[0]           

           addDir(name,URL,3001,iconimage,'','','','')
        except:pass  
    addDir('[COLOR royalblue]>> Next Page >>[/COLOR]',THE_URL,4002,'','','','',page)
            
       

def GetSearchLinks(name,url,iconimage,page):
  
    user='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36'
    headers={'User-Agent':user}
                          
    try:
       net.set_cookies(cookies_123)
       LINK=net.http_GET(url+'watching.html',headers=headers).content
       net.save_cookies(cookies_123)
       print 'CLOUDFLARE BYPASSED'
    except:
       import cloudflare
               
       LINK=cloudflare.solve(url+'watching.html',cookies_123,user)
                          
    uniques=[]
    try:movie_id = re.compile('movie-id="(.+?)"').findall(LINK)[0]
    except:movie_id = re.compile('updateMovieView\((.+?)\)').findall(LINK)[0]
    token = re.compile('player-token="(.+?)"').findall(LINK)[0]
    coookie_1 = re.compile('ds_hash: "(.*?)"').findall(LINK)[0]
    coookie_2 = re.compile('ds_token: "(.*?)"').findall(LINK)[0]
    coookie = coookie_1 + '=' + coookie_2

    net.set_cookies(cookies_123)                      
    LOAD =net.http_GET('http://123movies.to/ajax/get_episodes/%s/%s'%(movie_id,token),headers=headers).content
    link=LOAD.split('<div id="server-')
    for p in link:
        #try:
             host= p.split('"')[0]
           
             HTML=p.split('<a title="')

             for d in HTML:
                 TITLE=d.split('"')[0]
                 if 'Season' in name:
                    TITLE=TITLE
                    if TITLE not in uniques:
                       uniques.append(TITLE)
                       if ':' in TITLE:
                           addDir(TITLE,LOAD,3010,iconimage,'','',coookie,'')
                           xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)   
                 else:
                    TITLE=name+' - '+TITLE
          
                    try:
                        YEAR=re.compile('Release:</strong>(.+?)<').findall(LINK)[0].strip()
                        #print Year
                        token = re.compile('hash="(.+?)"').findall(d)[0]
                        SERVER=d.split('loadEpisode(')[1]
                        server=SERVER.split(',')[0]
                        episodeid=re.compile(',(.+?),').findall(SERVER)[0]

                        URL='http://123movies.to/ajax/load_episode/%s/%s' % (episodeid,token)                            
                        
                        #print HTML
                        addDir(TITLE,URL,3002,iconimage,'','',coookie,'')
                        

                    except:pass
                    
    match=re.compile('data-episodes="(.+?)-(.+?)"').findall(LOAD)
  
    for episodeid , token in match:

      URL='http://123movies.to/ajax/load_episode/%s/%s' % (episodeid,token)                            
      addDir('.'+name+' HD',URL,3002,iconimage,'','',coookie,'')
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)      


def GetEpisodeLinks(name,LOAD,iconimage,page):
    NAME = name
    link=LOAD.split('<div id="server-')
    for p in link:
        #try:
             host= p.split('"')[0]
           
             HTML=p.split('<a title="')

             for d in HTML:
                 TITLE=d.split('"')[0]
          
                 try:
                     token = re.compile('hash="(.+?)"').findall(d)[0]
                     SERVER=d.split('loadEpisode(')[1]
                     server=SERVER.split(',')[0]
                     episodeid=re.compile(',(.+?),').findall(SERVER)[0]

                     URL='http://123movies.to/ajax/load_episode/%s/%s' % (episodeid,token)                            
                     
                     if NAME in TITLE:
                         addDir(TITLE,URL,3002,iconimage,'','',page,'')
                     

                 except:pass                
    match=re.compile('data-episodes="(.+?)-(.+?)"').findall(LOAD)

    for episodeid , token in match:

      URL='http://123movies.to/ajax/load_episode/%s/%s' % (episodeid,token)                            
      addDir('.'+NAME+' HD',URL,3002,iconimage,'','',page,'')
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)

                 
def PLAY_DEMAND_STREAM(name, url, iconimage,cookie):

   headers={'Cookie':cookie,'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36','Referer': 'http://123movies.to','x-requested-with':'XMLHttpRequest'}
   STREAM=[]
   NAMED=[]
   GRAB=[]
   uniques=[]
   try:
      #net.set_cookies(cookies_123)
      print 'CLOUDFLARE BYPASSED'
      HTML=net.http_GET(url,headers=headers).content
      
      if 'oops' in HTML.lower():
        dialog = xbmcgui.Dialog()
        return dialog.ok(THESITE.upper(), 'Sorry Channel',"", "Could Not Find A Stream") 
      match=re.compile('file="(.+?)".+?label="(.+?)"',re.DOTALL).findall(HTML)
      #print match
      for FINAL_URL , res in match:
           if len(res)>4:
              res='700'
           
           GRAB.append([FINAL_URL , res])
      matched=re.compile('file="(.+?)"',re.DOTALL).findall(HTML)

      for FINAL_URL  in matched:
   
           HOST=FINAL_URL.split('://')[1]
           HOST=HOST.split('/')[0]              
           GRAB.append([FINAL_URL , '700'])
           
      for FINAL_URL , res  in GRAB:
           HOST=FINAL_URL.split('://')[1]
           HOST=HOST.split('/')[0]                                  
            
           if not '.srt' in FINAL_URL:
               res=res.replace('p','')
               
               res=int(res)
               if (res > 700):
                   res='[COLOR green]1080P[/COLOR]'
                   NAME='%s - [COLOR royalblue]%s[/COLOR]' %(res,HOST.upper())
                   if FINAL_URL not in uniques:
                      uniques.append(FINAL_URL)   
                      STREAM.append(FINAL_URL)
                      NAMED.append(NAME)
             
              
               if (res > 500):
                   res='[COLOR yellow]720P[/COLOR]'
                   NAME='%s - [COLOR royalblue]%s[/COLOR]' %(res,HOST.upper())
                   if FINAL_URL not in uniques:
                      uniques.append(FINAL_URL)   
                      STREAM.append(FINAL_URL)
                      NAMED.append(NAME)                

                        
               if (res < 500):
                   res='[COLOR orange]SD[/COLOR]'
                 

                   NAME='%s - [COLOR royalblue]%s[/COLOR]' %(res,HOST.upper())
                   if FINAL_URL not in uniques:
                      uniques.append(FINAL_URL)   
                      STREAM.append(FINAL_URL)
                      NAMED.append(NAME)
                        
                       
   except:pass
   url=STREAM[xbmcgui.Dialog().select('Choose Source !!', NAMED)]
   if 'streaming.fshare' in url:
      req = urllib2.Request(url, headers=headers) 
      url = urllib2.urlopen( req )  .geturl()    
      #url=urllib.urlopen(url).geturl()
      print url
   liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
   liz.setInfo(type='Video', infoLabels={'Title':name})
   liz.setProperty("IsPlayable","true")
   liz.setPath(url.replace('amp;',''))
   xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

                    

def PlayOnDemand(url):
    import urlresolver
    
    if 'googlevideo' in url or 'blogspot' in url:
        url=url
    elif not 'http' in url:
        url=afdah(url)
    elif 'http://vk' in url:
        url=GrabVK(url)

    elif 'movreel' in url:
        import movreel
        url=movreel.solve(url)
    elif 'xmovies8.tv' in url:
        url=url        
    else:
        import urlresolver
        url=urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title':description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)   
    
def Show_Down():
    dialog = xbmcgui.Dialog()
    dialog.ok(THESITE.upper(), 'Sorry Channel is Down',"Will Be Back Up Soon", "Try Another Channel")  
    
def Show_Cover():
    dialog = xbmcgui.Dialog()
    dialog.ok(THESITE.upper(), '',"Sorry We Dont Cover This Channel", "")    

    
def PLAY_FROM_EVENTS(name, url, iconimage, play, description):
    name=name.split('[COLOR green]')[1].replace('[/COLOR]','')
    name=name.replace('/',',').strip()
    if not 'EPL' in name:
       name.replace('-','').strip()
    nameFINAL=[]
    urlFINAL=[]
    
    if ',' in name:
        nameSelect=[]
        urlSelect=[]
        name=name.split(',')
        for p in name:
            urlSelect.append(p.strip().lower())
            nameSelect.append(p.strip())
        TITLE = urlSelect[xbmcgui.Dialog().select('Please Select Channel', nameSelect)]      
        TITLE=TITLE.replace(' ','').lower().strip()
        link = server().split('{')
        for YOYO in link:
            if TITLE in YOYO.replace(' ','').lower():
                print YOYO
                id = re.compile('"id":"(.+?)"').findall(YOYO)[0]
                NAME = re.compile('"title":"(.+?)"').findall(YOYO)[0]
                #GENRE = re.compile('"mediaid":"(.+?)"').findall(YOYO)[0]
                urlFINAL.append(id)
                nameFINAL.append('[COLOR lime]%s[/COLOR]'%(NAME))
        if urlFINAL:
            return urlFINAL[xbmcgui.Dialog().select('Multiple Channels Found', nameFINAL)] 
        else:
            return False

                       
    else:
    
        NAME=name.replace(' ','').lower().strip()
        link = server().split('{')
        for YOYO in link:
                match = re.compile('"id":"(.+?)".+?"title":"(.+?)"').findall(YOYO)
                for id,NAME_ in match :
                    #print NAME
                    #print NAME_.replace(' ','').lower().strip()
                    if NAME in NAME_.replace(' ','').lower().strip():
                        urlFINAL.append(id)
                        nameFINAL.append('[COLOR lime]%s[/COLOR]'%(NAME_))
        if urlFINAL:
            return urlFINAL[xbmcgui.Dialog().select('Multiple Channels Found', nameFINAL)] 
        else:
            return False
            
 
def EVENTS():
    link = OPEN_URL('http://channelstatus.weebly.com/upcoming-events.html')
    link=link.split('<div class="paragraph" style="text-align:left;"')[1]
    link=link.split('>***')
    for p in link:
        try:
            DATE=re.compile('(.+?)\*').findall(p)[0]
            addDir('[COLOR cyan]'+DATE+'[/COLOR]','',2000,'','False','','')  
            match=re.compile('\[(.+?)\].+?/strong>(.+?) - (.+?)<br',re.DOTALL).findall (p)
            for TIME ,VS , CHANNEL in match:

                CHANNEL=CHANNEL.replace('beIN','beIN Sports ').replace('Sports  Sports','Sports').replace('__','')
                name= '[COLOR white][%s][/COLOR][COLOR yellow]- %s -[/COLOR][COLOR green]%s[/COLOR]' %(TIME.replace('__',''),VS.replace('__',''),CHANNEL.replace('__',''))
                addDir(name,'url',2,'','GET_EVENT','','')       
        except:pass     
            
        
        
        
def get_params(path):
    params = {}
    path   = path.split('?', 1)[-1]
    pairs  = path.split('&')

    for pair in pairs:
        split = pair.split('=')
        if len(split) > 1:
            params[split[0]] = urllib.unquote_plus(split[1])

    return params


def getSetting(setting):
        import json
        setting = '"%s"' % setting
 
        query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (setting)
        response = xbmc.executeJSONRPC(query)

        response = json.loads(response)                

        if response.has_key('result'):
            if response['result'].has_key('value'):
                return response ['result']['value'] 


def setSetting(setting, value):



    query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"%s","value":%s}, "id":1}' % (setting, value)
    
    xbmc.executeJSONRPC(query)
    xbmc.executebuiltin("Container.Refresh") 

    
         
def Tools():
    addDir('Delete Cache','.f4m',16006,'','','','',0)
    if ADDON.getSetting('hls')=='true':
       last='RTMP'
    else:
       last='HLS'
    addDir('Speed Test','.f4m',16001,'','','','',0)   
    addDir('Change Username or Password','.f4m',16002,'','','','',0)
    addDir('Use %s Stream'% last,'.f4m',16003,'','','','',0)

    if int(getSetting('videoplayer.stretch43'))<4:       
        addDir('Force 16:9 Video','.f4m',16004,'','','','videoplayer.stretch43',4)

        
    if getSetting('videoplayer.usedxva2')==True:      
        addDir('Disable Hardware Acceleration','.f4m',16004,'','','','videoplayer.usedxva2','false')
    else:      
        addDir('Enable Hardware Acceleration','.f4m',16004,'','','','videoplayer.usedxva2','true')
    addDir('Delete Cookie','.f4m',203,'','','','',0)

    

    

def changeEnableHLS():
    if ADDON.getSetting('hls')=='true':
       change='false'
    else:
       change='true'
       
    ADDON.setSetting('hls',change)
    xbmc.executebuiltin("Container.Refresh")

def CheckUpdate():
    dialog = xbmcgui.Dialog()
    print 'http://lockedtv.xyz/repo/'+ADDON.getSetting('site')+'/plugin.video.cubetv/addon.xml'
    link=OPEN_URL('http://lockedtv.xyz/repo/'+ADDON.getSetting('site')+'/plugin.video.cubetv/addon.xml')
    match=re.compile('name=".+?" version="(.+?)"').findall(link)[0]
    if ADDON.getAddonInfo('version')==match:

        dialog.ok(THESITE.upper(),'', "You Are On Latest Version", "")
    else:   
        xbmc.executebuiltin('UpdateLocalAddons') 
        xbmc.executebuiltin("UpdateAddonRepos")
        dialog.ok(THESITE.upper(),'', "Updating Repo Now", "")
        

def Deletecache():
     dialog = xbmcgui.Dialog()
     packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
   
     for root, dirs, files in os.walk(packages_cache_path):
         file_count = 0
         file_count += len(files)
         
     # Count files and give option to delete
         if file_count > 0:

             dialog = xbmcgui.Dialog()
             for f in files:
                 os.unlink(os.path.join(root, f))
             for d in dirs:
                 shutil.rmtree(os.path.join(root, d))


     xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
     if os.path.exists(xbmc_cache_path)==True:    
         for root, dirs, files in os.walk(xbmc_cache_path):
             file_count = 0
             file_count += len(files)
        
         # Count files and give option to delete
             if file_count > 0:

                  for f in files:
                      try:
                          os.unlink(os.path.join(root, f))
                      except:
                          pass
                  for d in dirs:
                      try:
                          shutil.rmtree(os.path.join(root, d))
                      except:
                          pass
 
     xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'temp')
     if os.path.exists(xbmc_cache_path)==True:    
         for root, dirs, files in os.walk(xbmc_cache_path):
             file_count = 0
             file_count += len(files)
        
         # Count files and give option to delete
             if file_count > 0:
 
                 
                  for f in files:
                      try:
                          os.unlink(os.path.join(root, f))
                      except:
                          pass
                  for d in dirs:
                      try:
                          shutil.rmtree(os.path.join(root, d))
                      except:
                          pass
     dialog.ok(THESITE.upper(),'', "All Done And Deleted", "")

     

    



def addDir(name,url,mode,iconimage,play,date,description,page=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&play="+urllib.quote_plus(play)+"&date="+urllib.quote_plus(date)+"&description="+urllib.quote_plus(description)+"&page="+str(page)
        #print name+'='+u
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Premiered":date,"Plot":description} )
        menu=[]
        if mode == 3000:
            menu.append(('[COLOR orange]Remove Search[/COLOR]','XBMC.Container.Update(%s?mode=3004&name=%s)'% (sys.argv[0],name)))
            liz.addContextMenuItems(items=menu, replaceItems=True)
        else:        
            liz.addContextMenuItems(items=menu, replaceItems=False)
        if mode == 2 or mode==7  or mode==2004 or mode==3002 or mode==16001 or mode==16002 or mode==16003 or mode==16004 or mode==16005 or mode==16006 or mode==203 or mode==2007:
            if not '.f4m' in url:
                liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)    
        return ok



def addLink(name,url,iconimage, fanart):
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable","true")
        liz.setProperty("Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)

        
def setView(content, viewType):
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type
                      
               
params      = get_params(sys.argv[2]) 
url=None
name=None
mode=None
iconimage=None
date=None
description=None
page=None

try:
        url=params["url"]
except:
        pass
try:
        name=params["name"]
except:
        pass
try:
        iconimage=params["iconimage"]
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:
        play=params["play"]
except:
        pass
try:
        date=params["date"]
except:
        pass
try:
        description=params["description"]
except:
        pass
try:        
        page=int(params["page"])
except:
        try:        
               page=params["page"]
        except:
               pass

if mode==2:
        PLAY_STREAM(name,url,iconimage,play,description)

        
elif mode==4:
        GENRES(name,url)        
        
elif mode==3:
        REPLAY()

elif mode==5:
        OnDemand(url)


elif mode==6:
        OnDemandLinks(url)

elif mode==7:
        PlayOnDemand(url)         
        
        
elif mode==201:
        fullguide(name,url,iconimage,description)
        
elif mode==202:
        LOGGEDIN()
        try:GRAB_AUTH()
        except:pass
        Show_Dialog()
        
elif mode==203:
   
        try:os.remove(cookie_jar)
        except:pass
        Show_Dialog()

elif mode==204:
        downloadchannel()      
        
elif mode==205:
        LOGOUT()   
        
elif mode==1999:
        EVENTS()        
        
elif mode==2001:
        ADDON.openSettings()

elif mode==2004:
        PlayMikey(name,url,iconimage)
        
elif mode==2005:
        SportsOnDemand(url)

elif mode==20050:
        addDir('NFL',URL_SITE+'/apisprotected/usa.php',2005,'http://sgstreams.ca/images/cat_images/usa.png','','','')           
        addDir('MLB',URL_SITE+'/apisprotected/mlb.php',2005,'http://sgstreams.ca/images/cat_images/usa.png','','','')
        addDir('NHL',URL_SITE+'/apisprotected/nhl.php',2005,'http://sgstreams.ca/images/cat_images/usa.png','','','')
        addDir('NBA',URL_SITE+'/apisprotected/nba.php',2005,'http://sgstreams.ca/images/cat_images/usa.png','','','')
        
elif mode==2009:
        schedule(url)

elif mode==3000:
     SEARCH(url)

elif mode==3001:
     GetSearchLinks(name,url,iconimage,description)      


elif mode==3010:
     GetEpisodeLinks(name,url,iconimage,description) 

elif mode==3002:
     PLAY_DEMAND_STREAM(name,url,iconimage,description)

elif mode==3003:
     MySearch()

elif mode == 3004:
    
    favs = ADDON.getSetting('favs').split(",")
    try:
        favs.remove(name)
        ADDON.setSetting('favs', ",".join(favs))
    except:pass
    
elif mode == 4000:
    OnDemandFirstCat()

elif mode == 4001:
    OnDemandSecondCat(url)

elif mode == 4002:
    OnDemandThirdCat(url,page)

elif mode==12000:
     istream()
     
elif mode==16000:
     Tools()
     
elif mode==16001:
     import speedtest

elif mode==16002:
     ADDON.openSettings()

elif mode==16003:
     changeEnableHLS()

elif mode==16004:
     setSetting(description, page)
     
elif mode==16005:
     CheckUpdate()

elif mode==16006:
     Deletecache()     
else:
        #just in case mode is invalid 
        CATEGORIES()

               
xbmcplugin.endOfDirectory(int(sys.argv[1]))

