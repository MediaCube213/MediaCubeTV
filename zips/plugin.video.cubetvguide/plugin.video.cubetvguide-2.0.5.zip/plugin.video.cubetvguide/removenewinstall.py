
import xbmcaddon,xbmc,os,shutil





ADDON = xbmcaddon.Addon('plugin.video.cubetvguide')

ME= xbmc.translatePath(os.path.join('special://home/addons/plugin.video.cubetvguide', 'removenewinstall.py'))

datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
for root, dirs, files in os.walk(datapath):
   for f in files:
        os.unlink(os.path.join(root, f))
   for d in dirs:
        shutil.rmtree(os.path.join(root, d))
try:
    os.rmdir(datapath)
except:
    pass

